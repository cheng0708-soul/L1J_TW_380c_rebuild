package l1j.server.server.afk;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import l1j.server.server.model.Instance.L1PcInstance;

/**
 * 掛機控制器（入口）
 * - 提供掛機開/關總開關
 * - 封裝每位玩家的掛機狀態
 * - 切換為 ON 時啟動 AfkCruiseEngine；切換為 OFF 時停止
 */
public class AfkController {

    // 使用玩家物件ID作為鍵，記錄是否在掛機中
    private static final Map<Integer, Boolean> STATES = new ConcurrentHashMap<>();

    /** 讀取掛機狀態 */
    public static boolean isAfk(L1PcInstance pc) {
        if (pc == null) return false;
        return STATES.getOrDefault(pc.getId(), Boolean.FALSE);
    }

    /** 切換掛機開關：ON→OFF / OFF→ON */
    public static void toggle(L1PcInstance pc) {
        if (pc == null) return;
        boolean now = isAfk(pc);
        boolean next = !now;
        STATES.put(pc.getId(), next);

        if (next) {
            // 開啟掛機：啟動巡航/AI 引擎
            try {
                AfkCruiseEngine.start(pc); // 依你專案現有實作
                pc.sendPackets(new l1j.server.server.serverpackets.S_SystemMessage("自動掛機：已啟動"));
            } catch (Throwable t) {
                STATES.put(pc.getId(), false);
                pc.sendPackets(new l1j.server.server.serverpackets.S_SystemMessage("自動掛機啟動失敗：" + t.getMessage()));
            }
        } else {
            // 關閉掛機：停止巡航/AI 引擎
            try {
                AfkCruiseEngine.stop(pc);  // 依你專案現有實作
                pc.sendPackets(new l1j.server.server.serverpackets.S_SystemMessage("自動掛機：已停止"));
            } catch (Throwable t) {
                pc.sendPackets(new l1j.server.server.serverpackets.S_SystemMessage("自動掛機停止時發生錯誤：" + t.getMessage()));
            }
        }
    }

    /** 供死亡/回村/下線等情況統一關閉 */
    public static void forceOff(L1PcInstance pc) {
        if (pc == null) return;
        if (isAfk(pc)) {
            STATES.put(pc.getId(), false);
            try { AfkCruiseEngine.stop(pc); } catch (Throwable ignore) {}
        }
    }
}
