package l1j.server.server.afk;

import l1j.server.server.model.Instance.L1PcInstance;

/**
 * 供 AFK 尋路 / 重置 Path 用；提供 static 與 instance 兩種入口以相容舊碼。
 */
public class AfkPathService {

    // --- static 入口（常見呼叫：AfkPathService.clear(pc)） ---
    public static void clear(final L1PcInstance pc) { /* no-op 占位 */ }

    public static void stepToward(final L1PcInstance pc, final int x, final int y) { /* no-op */ }

    // --- instance 入口（若有用 new AfkPathService().clear(pc) 也能編過） ---
    public void clearPath(final L1PcInstance pc) { clear(pc); }

    public void stepToward(final L1PcInstance pc, final int x, final int y, final int dist) {
        stepToward(pc, x, y);
    }
}